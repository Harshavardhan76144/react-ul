package com.demo.Service;
import java.math.BigInteger;
import java.util.List;
import com.demo.Entity.User;
import com.demo.Exception.UserException;

public interface UserService {
	public BigInteger addUser(User user);
	public List<User> getAllUsersDetails();
	public User getUserById(BigInteger id) throws UserException;
	public void deleteUserById(BigInteger id) throws UserException;
	public User updateUser(User user);
	
}
