package com.demo.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.demo.Entity.Airport;
import com.demo.Exception.AirportException;
import com.demo.Repository.AirportRepository;

@Service
@Transactional
public class AirportServiceImpl implements AirportService{
	@Autowired
	private AirportRepository airportRepository;
	@Override
	public List<Airport> getAllAirports() {
		return airportRepository.findAll();
	}

	@Override
	public Airport getAirportInfoBycode(String airportCode) throws AirportException{
		return airportRepository.findById(airportCode).orElseThrow(()->new AirportException("Details Not Found"));
	}

}
