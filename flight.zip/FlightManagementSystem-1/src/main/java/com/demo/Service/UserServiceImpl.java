package com.demo.Service;
import java.math.BigInteger;
import java.util.List;
import java.util.Optional;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.demo.Entity.User;
import com.demo.Exception.UserException;
import com.demo.Repository.UserRepository;

@Service
@Transactional
public class UserServiceImpl implements UserService{
	
	@Autowired
	private UserRepository userRepository;

	@Override
	public List<User> getAllUsersDetails() {
		return userRepository.findAll();
	}
	
	@Override
	public User getUserById(BigInteger id) throws UserException {
		return userRepository.findById(id).orElseThrow(()->new UserException("User details not found for the given id."));
	}

	@Override
	public void deleteUserById(BigInteger id) throws UserException {
		userRepository.findById(id).orElseThrow(()->new UserException("User details not found for the given id."));
		userRepository.deleteById(id);
		
	}

	
   
	@Override
	  public User updateUser(User user) { 
		 Optional<User> optional =userRepository.findById(user.getUserId()); 
		 User userdata=null;
		 if(optional.isPresent()) { 
			 userdata=optional.get();
			 userdata.setUserName(user.getUserName());
			 userdata.setUserEmail(user.getUserEmail());
			 userdata.setPassword(user.getPassword());
			 userdata.setUserPhone(user.getUserPhone()); 
	  	}
		
		 return userdata; 
	}
	 

	@Override
	public BigInteger addUser(User user) {
		userRepository.save(user);
		return user.getUserId();	
	}	
}
