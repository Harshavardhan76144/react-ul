package com.demo.Service;

import java.util.List;

import com.demo.Entity.Airport;
import com.demo.Exception.AirportException;


public interface AirportService {
	public List<Airport> getAllAirports();
	public Airport getAirportInfoBycode(String airportCode)throws AirportException;

}
