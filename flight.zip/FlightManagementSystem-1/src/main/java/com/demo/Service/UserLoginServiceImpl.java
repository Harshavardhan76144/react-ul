package com.demo.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.demo.Entity.UserLogin;
import com.demo.Exception.UserNotFoundException;
import com.demo.Repository.UserLoginRepository;
@Service
@Transactional
public class UserLoginServiceImpl implements UserLoginService{
	@Autowired
	private UserLoginRepository userLoginRepository;
	@Override
	public UserLogin validateUser(String userId, String userPassword) throws UserNotFoundException {
		return userLoginRepository.findByUserIdAndUserPassword(userId, userPassword).orElseThrow(()->new UserNotFoundException("Invalid User"));
	}

}
