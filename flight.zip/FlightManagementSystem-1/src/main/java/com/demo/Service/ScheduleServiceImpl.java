package com.demo.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.demo.Entity.Schedule;
import com.demo.Exception.ScheduleException;
import com.demo.Exception.ScheduleFlightException;
import com.demo.Repository.ScheduleRepository;
@Service
@Transactional
public class ScheduleServiceImpl implements ScheduleService {
	
	@Autowired
	private ScheduleRepository repository;

	@Override
	public List<Schedule> getAllSchedules() 
	{
		return repository.findAll();
	}

	@Override
	public String saveSchedule(Schedule schedule) 
	{
		Schedule s=repository.save(schedule);
		String msg="Schedule details saved succesfully";
		return msg;
	}

	@Override
	public String deleteSchedule(Integer sid) 
	{
		repository.deleteById(sid);
		String msg="Deleted succesfully";
		return msg;
	}

	@Override
	public Schedule getScheduleById(Integer sid) {
		return repository.findById(sid).get();
	}


	

}
