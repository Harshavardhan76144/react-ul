package com.demo.Service;
import java.util.List;
import com.demo.Entity.Airport;
import com.demo.Entity.ScheduleFlight;
import com.demo.Exception.ScheduleFlightException;

public interface ScheduleFlightService {
	public List<ScheduleFlight> getAllScheduledFlights();
	
	public String deleteByscheduleflightid(Integer scheduleflightid)throws ScheduleFlightException;
	
	public ScheduleFlight modifyscheduleflight(ScheduleFlight sf);
	
	public List<ScheduleFlight> getAllScheduledByFlightNumber(Integer flightnumber)throws ScheduleFlightException;
	
	public String addScheduleFlight(ScheduleFlight scheduleFlight);
	
	public List<ScheduleFlight> getScheduleFlightSourceAiport(Airport sourceAirport);
	
	public List<ScheduleFlight> getAllScheduledByDate(String departureDate)throws ScheduleFlightException;

	
}
