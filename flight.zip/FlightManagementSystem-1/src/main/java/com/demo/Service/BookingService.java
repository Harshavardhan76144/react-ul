package com.demo.Service;

import java.math.BigInteger;
import java.util.List;

import com.demo.Entity.Booking;
import com.demo.Exception.BookingException;

public interface BookingService {
	public List<Booking> getAllBookingDetails();
	public Booking getBookingById(BigInteger id) throws BookingException;
	public void deleteByBookingId(BigInteger id)throws BookingException;
	public Booking updateBooking(Booking booking);
	public String addBooking(Booking booking);
	
}
