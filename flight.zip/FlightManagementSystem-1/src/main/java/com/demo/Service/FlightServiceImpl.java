package com.demo.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.demo.Entity.Flight;
import com.demo.Repository.FlightRepository;

@Service
@Transactional
public class FlightServiceImpl implements FlightService{
	@Autowired
	private FlightRepository flightRepository;
	@Override
	public List<Flight> getAllFlights() {
		return flightRepository.findAll();
	}
	
	@Override
	public Flight getByFlightNumber(Integer flightNumber) {
		return flightRepository.findByflightNumber(flightNumber);
	}

	@Override
	public Integer addFlight(Flight flight) {
		flightRepository.save(flight);
		return flight.getFlightNumber();

	}

	@Override
	public Flight modifyFlightdetails(Flight flight) throws Exception {
		Optional<Flight> optional = flightRepository.findById(flight.getFlightNumber());
		if (optional.isPresent()) {
			flightRepository.save(flight);
		} else
			throw new Exception("Flight with number: " + flight.getFlightNumber() + " not exists");
		return flight;
	}

	@Override
	public String deleteByFlightNumber(Integer flightNumber) throws Exception {
		Optional<Flight> optional = flightRepository.findById(flightNumber);
		if (optional.isPresent()) {
			flightRepository.deleteById(flightNumber);
			return "Flight removed!!";
		} else
			throw new Exception("Flight with number: " + flightNumber + " not exists");

	}
		
}
