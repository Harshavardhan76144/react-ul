package com.demo.Service;

import com.demo.Entity.UserLogin;
import com.demo.Exception.UserNotFoundException;

public interface UserLoginService {
	public UserLogin validateUser(String userId,String userPassword) throws UserNotFoundException;
}
