package com.demo.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.demo.Entity.Airport;
import com.demo.Entity.ScheduleFlight;
import com.demo.Exception.ScheduleFlightException;
import com.demo.Repository.ScheduleFlightRepository;

@Service
@Transactional
public class ScheduleFlightServiceImpl implements ScheduleFlightService{
	
	@Autowired
	private ScheduleFlightRepository repository;
	@Override
	public List<ScheduleFlight> getAllScheduledFlights() {
		return repository.findAll();
	}

	@Override
	public String deleteByscheduleflightid(Integer scheduleflightid) throws ScheduleFlightException {
		repository.findById(scheduleflightid).orElseThrow(()-> new ScheduleFlightException("Details are not available"));
		repository.deleteById(scheduleflightid);
		String msg="Successfully Deleted";
		return msg;
	}

	@Override
	public ScheduleFlight modifyscheduleflight(ScheduleFlight sf) {
		Optional<ScheduleFlight>opt=repository.findById(sf.getScheduleFlightId());
		ScheduleFlight schefli=null;
		if(opt.isPresent()) {
			schefli=opt.get();
			schefli.setScheduleFlightId(sf.getScheduleFlightId());
			schefli.setAvailableSeats(sf.getAvailableSeats());
			schefli.setTicketCost(sf.getTicketCost());
			schefli.setScheduleFlightState(sf.getScheduleFlightState());
		}
		return schefli;
	}

	@Override
	public List<ScheduleFlight> getAllScheduledByFlightNumber(Integer flightnumber) throws ScheduleFlightException {
		List<ScheduleFlight> list= repository.findRecordsByFlightNumber(flightnumber);
		if(list.isEmpty())
		{
			throw new ScheduleFlightException("No Schedule Found for given Flight Number");
		}
		return list;
	}

	/*
	 * @Override public String addScheduleFlight(ScheduleFlight scheduleFlight) {
	 * repository.save(scheduleFlight); return "ScheduleFlight details are entered";
	 * }
	 */

	@Override
	public List<ScheduleFlight> getAllScheduledByDate(String departureDate) throws ScheduleFlightException {
		List<ScheduleFlight> list= repository.findRecordsByDate(departureDate);
		if(list.isEmpty())
		{
			throw new ScheduleFlightException("No Schedule found for given Date");
		}
		return list;
	}

	@Override
	public List<ScheduleFlight> getScheduleFlightSourceAiport(Airport sourceAirport) {
		return repository.getScheduleFlightBySourceAirport(sourceAirport);
	}

	@Override
	public String addScheduleFlight(ScheduleFlight scheduleFlight) {
		repository.save(scheduleFlight);
		return "ScheduleFlight details are successfully saved....";
	}

}
