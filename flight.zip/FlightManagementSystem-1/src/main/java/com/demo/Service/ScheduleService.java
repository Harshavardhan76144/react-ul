package com.demo.Service;

import java.util.List;

import com.demo.Entity.Schedule;
import com.demo.Exception.ScheduleException;

public interface ScheduleService {
	
	
	public List<Schedule> getAllSchedules();

	public String saveSchedule(Schedule schedule);
	
	public String deleteSchedule(Integer sid);
	
	public Schedule getScheduleById(Integer sid);
	
}