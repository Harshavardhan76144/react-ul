package com.demo.Service;

import java.math.BigInteger;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.demo.Entity.Booking;
import com.demo.Exception.BookingException;
import com.demo.Repository.BookingRepository;
@Service
@Transactional
public class BookingServiceImpl implements BookingService{
	@Autowired
	private BookingRepository bookingRepository;
	
	@Override
	public List<Booking> getAllBookingDetails() {
		return bookingRepository.findAll();
	}

	@Override
	public Booking getBookingById(BigInteger id) throws BookingException {
		return bookingRepository.findById(id).orElseThrow(()->new BookingException("Booking details not found for the given id."));
	}

	@Override
	public Booking updateBooking(Booking booking) {
		Optional<Booking> optional=bookingRepository.findById(booking.getBookingId());
		Booking booking1=null;
		if(optional.isPresent()) {
			booking1=optional.get();
			booking1.setBookingState(booking.getBookingState());
			booking1.setBookingDate(booking.getBookingDate());
			booking1.setTicketCost(booking.getTicketCost());
			booking1.setPassengerCount(booking.getPassengerCount());
		}return booking1;
	}

	@Override
	public String addBooking(Booking booking) {
		bookingRepository.save(booking);
		return "Booking details are entered..";
	}

	@Override
	public void deleteByBookingId(BigInteger id) throws BookingException {
		bookingRepository.findById(id).orElseThrow(()->new BookingException("Booking details not found for the given id."));
		bookingRepository.deleteById(id);
		
	}

	

	

}
