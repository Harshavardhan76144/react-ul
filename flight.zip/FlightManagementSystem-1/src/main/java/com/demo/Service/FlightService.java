package com.demo.Service;

import java.util.List;
import com.demo.Entity.Flight;

public interface FlightService {
	public List<Flight> getAllFlights();
	public String deleteByFlightNumber(Integer flightNumber) throws Exception;
	public Flight modifyFlightdetails(Flight flight) throws Exception;
    public Integer addFlight(Flight flight);
	public Flight getByFlightNumber(Integer flightNumber);

}
