package com.demo.Exception;

public class UserException extends Exception{
	public UserException(String msg) {
		super(msg);
	}

}
