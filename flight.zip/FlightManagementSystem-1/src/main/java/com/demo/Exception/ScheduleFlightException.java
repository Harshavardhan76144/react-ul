package com.demo.Exception;

public class ScheduleFlightException extends Exception{
	public ScheduleFlightException(String msg) {
		super(msg);
	}
}
