package com.demo.Exception;

public class FlightException extends Exception{
	public FlightException(String msg) {
		super(msg);
	}
}
