package com.demo.Exception;

public class AirportException extends Exception{
	public AirportException(String msg) {
		super(msg);
	}
}
