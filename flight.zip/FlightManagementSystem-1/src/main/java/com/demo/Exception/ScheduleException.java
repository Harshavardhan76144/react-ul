package com.demo.Exception;

public class ScheduleException extends Exception{
	public ScheduleException(String msg) {
		super(msg);
	}
}
