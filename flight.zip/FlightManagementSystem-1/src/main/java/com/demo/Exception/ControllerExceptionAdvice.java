package com.demo.Exception;
import java.util.stream.Collectors;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
@RestControllerAdvice
public class ControllerExceptionAdvice {
	@ExceptionHandler(UserException.class)
	public ResponseEntity<ErrorMessage> handleUserException(UserException userException) {
		ErrorMessage error = new ErrorMessage();
		error.setErrorCode(404);
		error.setErrorCodeDescription("Bad Request");
		error.setErrorMessage(userException.getMessage());
		return new ResponseEntity<>(error,HttpStatus.OK);
	}
	@ExceptionHandler(Exception.class)
	public ResponseEntity<ErrorMessage> handleUserException(Exception exception) {
		ErrorMessage error = new ErrorMessage();
		error.setErrorCode(501);
		error.setErrorCodeDescription("Internal Server Error");
		error.setErrorMessage(exception.getMessage());
		return new ResponseEntity<>(error,HttpStatus.OK);
	}
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<ErrorMessage> handleMethodArgumentInvalid1(MethodArgumentNotValidException exception){
		String errMsg=exception.getAllErrors().stream().map(error->error.getDefaultMessage()).collect(Collectors.joining(","));
		ErrorMessage error = new ErrorMessage();
		error.setErrorCode(404);
		error.setErrorCodeDescription("Bad Request");
		error.setErrorMessage(errMsg);
		return new ResponseEntity<>(error,HttpStatus.OK);
	}
	@ExceptionHandler(UserNotFoundException.class)
	public ResponseEntity<String> handleUserNotFoundException(UserNotFoundException userNotFoundException){
		return new ResponseEntity<String>(userNotFoundException.getMessage(),HttpStatus.NOT_FOUND);
	}
}
