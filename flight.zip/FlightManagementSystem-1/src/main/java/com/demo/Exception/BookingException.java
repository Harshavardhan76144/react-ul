package com.demo.Exception;

public class BookingException extends Exception{
	public BookingException(String msg) {
		super(msg);
	}
}
