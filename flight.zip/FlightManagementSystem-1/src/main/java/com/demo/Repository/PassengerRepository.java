package com.demo.Repository;

import java.math.BigInteger;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demo.Entity.Passenger;

public interface PassengerRepository extends JpaRepository<Passenger,BigInteger>{

}
