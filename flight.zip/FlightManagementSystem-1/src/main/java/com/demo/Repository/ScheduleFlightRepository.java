package com.demo.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.demo.Entity.Airport;
import com.demo.Entity.ScheduleFlight;

public interface ScheduleFlightRepository extends JpaRepository<ScheduleFlight,Integer>{
	
	@Query("select scheduleflight from ScheduleFlight scheduleflight where scheduleflight.flight.flightNumber=?1")
	List<ScheduleFlight> findRecordsByFlightNumber(Integer flightnumber);
	
	@Query("select sf from ScheduleFlight sf where sf.scheduleId.SourceAirport=?1")
	List<ScheduleFlight> getScheduleFlightBySourceAirport(Airport sourceAirport );
	
	@Query("select sf from ScheduleFlight sf where sf.scheduleId.departureDate=?1")
	List<ScheduleFlight> findRecordsByDate(String departureDate);




}
