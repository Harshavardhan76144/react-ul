package com.demo.Repository;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.demo.Entity.Flight;

public interface FlightRepository extends JpaRepository<Flight,Integer>{
	
	
	
	@Query("select flight from Flight flight where flightNumber=?1")
	public Flight findByflightNumber(Integer flightNumber);
	@Query("delete from Flight where flightNumber=?1")
	public Integer deleteByFlightNumber(Integer flightNumber);
}
