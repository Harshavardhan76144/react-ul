package com.demo.Repository;

import java.math.BigInteger;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demo.Entity.Booking;

public interface BookingRepository extends JpaRepository<Booking,BigInteger> {

}
