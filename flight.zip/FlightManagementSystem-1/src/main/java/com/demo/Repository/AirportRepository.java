package com.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demo.Entity.Airport;

public interface AirportRepository extends JpaRepository<Airport,String>{

}
