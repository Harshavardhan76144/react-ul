package com.demo.Entity;

import java.math.BigInteger;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="booking")
public class Booking {
	@Id
	@GeneratedValue
	@Column(name="bookingid")
	private BigInteger bookingId;
	@Column(name="bookingdate")
	private Date bookingDate;
	@Column(name="ticketcost")
	private Integer ticketCost;
	@Column(name="passengercount")
	private BigInteger passengerCount;
	@Column(name="bookingstate")
	private String bookingState;
	@ManyToOne
	@JoinColumn(name="userId",unique=true)
	private User user;
	@ManyToOne
	@JoinColumn(name="scheduleflightId",unique=true)
	private ScheduleFlight scheduleFlight;
	@OneToMany(targetEntity = Passenger.class,cascade=CascadeType.ALL)
	@JoinColumn(name="pnr_number",referencedColumnName="bookingId")
	private List<Passenger> passenger=new ArrayList<>();
	
	
	public List<Passenger> getPassenger() {
		return passenger;
	}
	public void setPassenger(List<Passenger> passenger) {
		this.passenger = passenger;
	}
	public BigInteger getBookingId() {
		return bookingId;
	}
	public void setBookingId(BigInteger bookingId) {
		this.bookingId = bookingId;
	}
	public Date getBookingDate() {
		return bookingDate;
	}
	public void setBookingDate(Date bookingDate) {
		this.bookingDate = bookingDate;
	}
	public Integer getTicketCost() {
		return ticketCost;
	}
	public ScheduleFlight getScheduleFlight() {
		return scheduleFlight;
	}
	public void setScheduleFlight(ScheduleFlight scheduleFlight) {
		this.scheduleFlight = scheduleFlight;
	}
	public void setTicketCost(Integer ticketCost) {
		this.ticketCost = ticketCost;
	}
	public BigInteger getPassengerCount() {
		return passengerCount;
	}
	public void setPassengerCount(BigInteger passengerCount) {
		this.passengerCount = passengerCount;
	}
	public String getBookingState() {
		return bookingState;
	}
	public void setBookingState(String bookingState) {
		this.bookingState = bookingState;
	}

	public User getUser() { 
		return user; 
	}
	public void setUser(User user) {
	  this.user = user; 
	}
	 
	
	

}
