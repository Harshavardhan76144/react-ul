package com.demo.Entity;
import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Entity
@Table(name="userinfo")
public class User {
	@Id
	@GeneratedValue
	@Column(name="userid")
	private BigInteger userId;
	@Column(name="usertype")
	private String userType;
	@NotNull(message="User name should not be null")
	@NotEmpty(message="User name should not be empty")
	@Column(name="username")
	private String userName;
	@NotNull(message="Phone number should not be null")
	@Pattern(regexp="(0|91)?[6-9][0-9]{9}",message="Please enter valid phone number")
	@Column(name="userphone")
	private String userPhone;
	@Column(name="useremail",unique=true)
	@NotEmpty(message="Field is mandatory should not be empty")
	@Email(message="Email is not valid")
	private String userEmail;
	@Pattern(regexp="^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,12}$",message="Please enter Valid Password.password must contains atleat one numeric value, lower case letter,upper case letter,special character,Minimum of 8 letters,no Spaces")
	@Column(name="userpassword")
	private String password;
	
	 

	public BigInteger getUserId() {
		return userId;
	}
	public void setUserId(BigInteger userId) {
		this.userId = userId;
	}
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public String getUserPhone() {
		return userPhone;
	}
	public void setUserPhone(String userPhone) {
		this.userPhone = userPhone;
	}
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	
	
	
	
}
