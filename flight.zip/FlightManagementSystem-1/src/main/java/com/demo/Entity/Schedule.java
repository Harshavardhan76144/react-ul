package com.demo.Entity;

import java.sql.Time;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;


@Entity
@Table(name="schedule")
public class Schedule {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@NotNull(message="Schedule Id should not be null")
	private Integer scheduleid;
	
	@OneToOne
	@JoinColumn(name="sourceairport")
	private Airport SourceAirport;
	
	@OneToOne
	@JoinColumn(name="destinationairport")
	private Airport DestinationAirport;
	
	@Column(name = "departuredate")
	private String departureDate;
	
	@Column(name = "departuretime")
	private Time departureTime;

	@Column(name = "arrivaldate")
	private String arrivalDate;
    
	@Column(name = "arrivaltime")
	private Time arrivalTime;
	
	
	public Airport getSourceAirport() {
		return SourceAirport;
	}
	public void setSourceAirport(Airport sourceAirport) {
		SourceAirport = sourceAirport;
	}
	public Airport getDestinationAirport() {
		return DestinationAirport;
	}
	public void setDestinationAirport(Airport destinationAirport) {
		DestinationAirport = destinationAirport;
	}

	public Integer getScheduleid() {
		return scheduleid;
	}
	public void setScheduleid(Integer scheduleid) {
		this.scheduleid = scheduleid;
	}
	public String getDepartureDate() {
		return departureDate;
	}
	public void setDepartureDate(String departureDate) {
		this.departureDate = departureDate;
	}
	public Time getDepartureTime() {
		return departureTime;
	}
	public void setDepartureTime(Time departureTime) {
		this.departureTime = departureTime;
	}
	public String getArrivalDate() {
		return arrivalDate;
	}
	public void setArrivalDate(String arrivalDate) {
		this.arrivalDate = arrivalDate;
	}
	public Time getArrivalTime() {
		return arrivalTime;
	}
	public void setArrivalTime(Time arrivalTime) {
		this.arrivalTime = arrivalTime;
	}


	
}
