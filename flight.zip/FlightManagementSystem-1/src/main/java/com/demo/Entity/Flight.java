package com.demo.Entity;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name="flight")
public class Flight {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@NotNull(message="flightNumber should not be null")
	@Column(name="flightnumber")
	private Integer flightNumber;
	
	@NotEmpty(message="flightModel should not be empty")
	@Column(name="flightmodel")
	private String flightModel;
	
	@NotEmpty(message="carrierName should not be empty")
	@Column(name="carriername")
	private String carrierName;
	
    //@Size(max=100,min=200,message="seatCapacity should be minimum 100, maximum 200")
	@NotNull(message="seatCapacity should not be null")
	@Column(name="seatcapacity")
	private Integer seatCapacity;
	@Column(name="flightstate")
	private String flightState; 
	public Integer getFlightNumber()
	{
		return flightNumber;
	}
	public void setFlightNumber(Integer flightNumber)
	{
		this.flightNumber = flightNumber;
	}
	public String getFlightModel() 
	{
		return flightModel;
	}
	public void setFlightModel(String flightModel) 
	{
		this.flightModel = flightModel;
	}
	public String getCarrierName() 
	{
		return carrierName;
	}
	public void setCarrierName(String carrierName)
	{
		this.carrierName = carrierName;
	}
	public Integer getSeatCapacity()
	{
		return seatCapacity;
	}
	public void setSeatCapacity(Integer seatCapacity)
	{
		this.seatCapacity = seatCapacity;
	}
	public String getFlightState() {
		return flightState;
	}
	public void setFlightState(String flightState) {
		this.flightState = flightState;
	}



}
