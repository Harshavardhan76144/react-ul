package com.demo.Entity;

import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="passenger")
public class Passenger {
	@Id
	@GeneratedValue
	@Column(name="pnr_number")
	private BigInteger pnrNumber;
	@Column(name="passenger_name")
	private String passengerName;
	@Column(name="passenger_age")
	private Integer passengerAge;
	@Column(name="passenger_UIN")
	private BigInteger passengerUIN;
	@Column(name="passengerstate")
	private String passengerState;
	
	public String getPassengerName() {
		return passengerName;
	}
	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}
	public Integer getPassengerAge() {
		return passengerAge;
	}
	public void setPassengerAge(Integer passengerAge) {
		this.passengerAge = passengerAge;
	}
	public BigInteger getPassengerUIN() {
		return passengerUIN;
	}
	public void setPassengerUIN(BigInteger passengerUIN) {
		this.passengerUIN = passengerUIN;
	}
	public String getPassengerState() {
		return passengerState;
	}
	public void setPassengerState(String passengerState) {
		this.passengerState = passengerState;
	}
	public BigInteger getPnrNumber() {
		return pnrNumber;
	}
	public void setPnrNumber(BigInteger pnrNumber) {
		this.pnrNumber = pnrNumber;
	}
	
}
