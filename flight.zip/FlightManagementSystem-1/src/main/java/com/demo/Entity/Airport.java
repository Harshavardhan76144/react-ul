package com.demo.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Entity
@Table(name="airport")
public class Airport {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="airportcode")
	@NotNull(message="Airport Code should not be Empty")
	@Pattern(regexp="[a-zA-Z]*",message="Airport Code should have only alphabets")
	@Size(min=3,max=3)
	private  String airportCode;
	@Pattern(regexp="[a-zA-z]*",message="Airport Name should have only alphabets")
	@Column(name="airportname")
	private String airportName;
	@Column(name="airportlocation")
	private String airportLocation;
	public String getAirportCode() {
		return airportCode;
	}
	public void setAirportCode(String airportCode) {
		this.airportCode = airportCode;
	}
	public String getAirportName() {
		return airportName;
	}
	public void setAirportName(String airportName) {
		this.airportName = airportName;
	}
	public String getAirportLocation() {
		return airportLocation;
	}
	public void setAirportLocation(String airportLocation) {
		this.airportLocation = airportLocation;
	}
	



}
