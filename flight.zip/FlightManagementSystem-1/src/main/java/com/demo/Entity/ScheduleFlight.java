package com.demo.Entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Entity
@Table(name="scheduleflight")
public class ScheduleFlight {
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Id
	@Column(name="scheduleflightid")
	@NotNull(message="Schedule Flight Id should not be null")
	private Integer scheduleFlightId;
	@Column(name="availableseats")
	private Integer availableSeats;
	@Min(value=5000,message="Ticket cost should at least 5000 Rs")
	@Column(name="ticketcost")
	private Integer ticketCost;
	@Pattern(regexp="[a-zA-Z]*",message="ScheduleFlight state should have only alphabets")
	@Size(min=3,max=3)
	@Column(name="scheduleflightstate")
	private String scheduleFlightState;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="scheduleid",unique=true)
	private Schedule scheduleId;
	
	@ManyToOne
	@JoinColumn(name="flightnumber")
	private Flight flight;
	
	
	public Flight getFlight() {
		return flight;
	}
	public void setFlight(Flight flight) {
		this.flight = flight;
	}

	
	public Schedule getScheduleId() {
		return scheduleId;
	}
	public void setScheduleid(Schedule scheduleId) {
		this.scheduleId = scheduleId;
	}

	
	
	
	public Integer getScheduleFlightId() {
		return scheduleFlightId;
	}
	public void setScheduleFlightId(Integer scheduleFlightId) {
		this.scheduleFlightId = scheduleFlightId;
	}



	public Integer getAvailableSeats() {
		return availableSeats;
	}
	public void setAvailableSeats(Integer availableSeats) {
			this.availableSeats = availableSeats;
	}
	public Integer getTicketCost() {
		return ticketCost;
	}
	public void setTicketCost(Integer ticketCost) {
		this.ticketCost = ticketCost;
	}
	public String getScheduleFlightState() {
		return scheduleFlightState;
	}
	public void setScheduleFlightState(String scheduleFlightState) {
		this.scheduleFlightState = scheduleFlightState;
	}





}
