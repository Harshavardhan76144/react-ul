package com.demo.Controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.demo.Entity.Schedule;
import com.demo.Exception.ScheduleException;
import com.demo.Exception.ScheduleFlightException;
import com.demo.Service.ScheduleService;

@CrossOrigin(origins="*")
@RequestMapping(value="/Schedule")
@RestController
public class ScheduleController {
	@Autowired
	private ScheduleService service;
	
		@GetMapping(value="/allSchedules")
		public ResponseEntity<List<Schedule>> getAllSchedules()
		{
			List<Schedule>allSchedules=service.getAllSchedules();
			return new ResponseEntity<List<Schedule>>(allSchedules,HttpStatus.CREATED);
		}

		@PostMapping(value="/saveSchedule")
		public ResponseEntity<String> saveSchedule(@RequestBody Schedule schedule)
		{
			String msg=service.saveSchedule(schedule);
			return new ResponseEntity<String>(msg,HttpStatus.CREATED);
		}
		
		
		@DeleteMapping(value="{sid}")
		public ResponseEntity<Map<String,String>> deleteSchedule(@PathVariable Integer sid)
		{
			String msg=service.deleteSchedule(sid);
			Map map=new HashMap();
			map.put("msg",msg);
			return new ResponseEntity<Map<String,String>>(map,HttpStatus.CREATED);
		}
		
		@GetMapping(value="{sid}")
		public ResponseEntity<Schedule> getScheduleById(@PathVariable Integer sid)
		{
			Schedule s=service.getScheduleById(sid);
			return new ResponseEntity<Schedule>(s,HttpStatus.OK);
		}
		
		
}