package com.demo.Controller;
import java.math.BigInteger;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.demo.Entity.User;

import com.demo.Exception.UserException;
import com.demo.Service.UserService;
@RestController
public class UserController {
	@Autowired
	private UserService userService;
	
	//List of All Users
	@GetMapping(value="/User")
	public ResponseEntity<List<User>> getAllUsersDetails(){
		List<User> list=userService.getAllUsersDetails();
		ResponseEntity<List<User>> response=new ResponseEntity<>(list,HttpStatus.OK);
		return response;
	}
	//List UserInfo By ID
		@GetMapping("/User/{userId}")
		public ResponseEntity<User> getUserById(@PathVariable("userId") BigInteger id) throws UserException {
			User user=userService.getUserById(id);
			ResponseEntity<User> response=new ResponseEntity<>(user,HttpStatus.OK);
			return response;
		}
		
		//Delete UserInfo By Id
		@DeleteMapping("/User/{userId}")
		public String deleteUserById(@PathVariable("userId") BigInteger id) throws UserException {
			userService.deleteUserById(id);
			return ("Successfully Deleted....");
		
		}
		//Update User Information in the table based on different criteria
		@PutMapping("/User")
		public ResponseEntity<User> updateUser(@Valid @RequestBody User user) {
			User user1 = userService.updateUser(user);
			ResponseEntity<User> response = new ResponseEntity<>(user1,HttpStatus.OK);
			return response;
		}
		//inserts
		@PostMapping("/User")
		public ResponseEntity<BigInteger> addUser(@Valid @RequestBody User user) {
			BigInteger userId= userService.addUser(user);
			ResponseEntity<BigInteger> response=new ResponseEntity<>(userId,HttpStatus.CREATED);
			return response;
		}
		

}
