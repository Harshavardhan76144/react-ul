package com.demo.Controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.Entity.UserLogin;
import com.demo.Exception.UserNotFoundException;
import com.demo.Service.UserLoginService;

@CrossOrigin(origins="*")
@RestController
@RequestMapping(value="/user")
public class UserLoginController {
	@Autowired
	private UserLoginService userLoginService;
	@PostMapping(value="/login")
	public ResponseEntity<Map<String,String>> validateUser(@RequestBody UserLogin userLogin) throws UserNotFoundException{
		UserLogin user=userLoginService.validateUser(userLogin.getUserId(),userLogin.getUserPassword());
		String message="Welcome"+user.getUserId();
		Map<String, String> map=new HashMap<String,String>();
		map.put("message", message);
		return new ResponseEntity<Map<String,String>>(map,HttpStatus.OK);
		
	}
}
