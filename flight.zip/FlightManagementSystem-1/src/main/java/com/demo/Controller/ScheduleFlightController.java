package com.demo.Controller;
import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.Entity.Airport;
import com.demo.Entity.ScheduleFlight;
import com.demo.Exception.ScheduleFlightException;
import com.demo.Service.ScheduleFlightService;
@RequestMapping(value="/ScheduleFlight")
@RestController
public class ScheduleFlightController {
	@Autowired
	private ScheduleFlightService service;
    // List of Scheduled Flights by Flight Number
	@GetMapping(value="/flightnumber/{fnumber}")
	public ResponseEntity<List<ScheduleFlight>>getAllScheduledByFlightNumber( @PathVariable("fnumber") Integer flightnumber) throws ScheduleFlightException {
		List<ScheduleFlight> list=service.getAllScheduledByFlightNumber(flightnumber);
		ResponseEntity<List<ScheduleFlight>> response=new ResponseEntity<>(list,HttpStatus.OK);
		return response;
	}
	//List of all Scheduled Flights with all the Details
	@GetMapping(value="/AllScheduleFlight")
	public ResponseEntity<List<ScheduleFlight>> getAllScheduledFlights(){
		List<ScheduleFlight>list=service.getAllScheduledFlights();
		ResponseEntity<List<ScheduleFlight>> response=new ResponseEntity<>(list,HttpStatus.OK);
		return response;
	}
	

	//Delete a Scheduled Flight from available flights
	@DeleteMapping(value="/{sfi}")
	public String deletescheduleflightbyid(@Valid @PathVariable("sfi")Integer scheduleflightid) throws ScheduleFlightException {
		service.deleteByscheduleflightid(scheduleflightid);
		String msg="Successfully Deleted";
		return msg;
	}
	//Modify the Details of Scheduled File
	@PutMapping(value="/update")
	public ResponseEntity<ScheduleFlight>modifyscheduleflight(@Valid @RequestBody ScheduleFlight sf) {
		ScheduleFlight sfl=service.modifyscheduleflight(sf);
		ResponseEntity<ScheduleFlight> response=new ResponseEntity<>(sfl,HttpStatus.ACCEPTED);
		return response;
	}
	//Schedules a flight
	@PostMapping("/saveScheduleFlight")
	public ResponseEntity<ScheduleFlight> saveScheduleFlight(@Valid @RequestBody ScheduleFlight sf){
		String sfl=service.addScheduleFlight(sf);
		ResponseEntity<ScheduleFlight> response=new ResponseEntity(sfl ,HttpStatus.CREATED);
		return response;
	}

	  //lists Scheduled flights with SourceAirport 
	  
	  @GetMapping("/Airport/{Airport}")
	  public List<ScheduleFlight> getscheduleflightBySourceAirport(@PathVariable("Airport") Airport sourceAirport) {
		  return (List<ScheduleFlight>) service.getScheduleFlightSourceAiport(sourceAirport);
	  }
	  //lists Scheduled flight by Date
	  @GetMapping("/Date/{Date}")
	  public ResponseEntity<List<ScheduleFlight>>getAllScheduledByDate(@Valid  @PathVariable("Date") String departureDate) throws ScheduleFlightException
	  {
		List<ScheduleFlight> list=service.getAllScheduledByDate(departureDate);
		ResponseEntity<List<ScheduleFlight>> response=new ResponseEntity<>(list,HttpStatus.OK);
		return response;
	  }
	
}
	
