package com.demo.Controller;

import java.util.List;


import javax.validation.constraints.Size;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.demo.Entity.Airport;
import com.demo.Exception.AirportException;
import com.demo.Service.AirportService;

@RestController
@Validated
public class AirportController {
	@Autowired
	private AirportService airportService;
	//List of all Airports present in Database
	@GetMapping(value="/airport")
	public ResponseEntity<List<Airport>> geAlltAirports(){
		List<Airport>list= airportService.getAllAirports();
		ResponseEntity<List<Airport>>response=new ResponseEntity<>(list,HttpStatus.OK);
		return response;	}
	//Find Airport Details by AirportCode
	@GetMapping(value="/airportcode/{ecode}")
	public ResponseEntity<Airport> getAirportInfoByCode(@PathVariable("ecode")	@Size(min=3,max=3) String airportCode) throws AirportException{
		Airport airport=airportService.getAirportInfoBycode(airportCode);
		ResponseEntity<Airport> response=new ResponseEntity<>(airport,HttpStatus.OK);
		return response;
	}
}
