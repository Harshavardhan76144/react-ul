package com.demo.Controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.demo.Entity.Flight;
import com.demo.Exception.FlightException;
import com.demo.Service.FlightService;

@RestController
public class FlightController {
	@Autowired
	private FlightService flightService;
	
	//List All Flight Details
		@GetMapping(value="/Flight")
		public ResponseEntity<List<Flight>> getAllFLights()
		{
			List<Flight> list=flightService.getAllFlights();
			ResponseEntity<List<Flight>> response=new ResponseEntity<>(list,HttpStatus.OK);
			return response;
		}
		
		
		//List Flight By FlightNumber
		@GetMapping("/Flight/{flightNumber}")
		public ResponseEntity<Flight> getByFlightNumber(@PathVariable("flightNumber") Integer flightNumber) throws FlightException{
			Flight flight=flightService.getByFlightNumber(flightNumber);
			ResponseEntity<Flight> response=new ResponseEntity<>(flight,HttpStatus.OK);
			return response;
		}
		
		//Inserting the Flight Details
		@PostMapping("/Flight")
		public ResponseEntity<Integer> saveFlight(@Valid @RequestBody Flight flight)
		{
			Integer flightNum=flightService.addFlight(flight);
			ResponseEntity<Integer> response=new ResponseEntity<>(flightNum,HttpStatus.CREATED);
			return response; 
		}
		@PutMapping("/Flight")
		public ResponseEntity<Flight> modifyFlight(@RequestBody Flight flight) throws Exception {
			Flight flightOutput=flightService.modifyFlightdetails(flight);
			ResponseEntity<Flight> response = new ResponseEntity<>(flightOutput,HttpStatus.OK);
			return response;
			
		}
		
		@DeleteMapping("/deleteFlight/{id}")
		public void removeFlight(@PathVariable("id") Integer flightNumber) throws Exception {
			flightService.deleteByFlightNumber(flightNumber);
		}
		
		

}
